Set-Itemproperty -path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess\5ceed41e-3bef-42e2-9ad9-eb1335f89a75_t1jx13gsykmd2' -Name 'Value' -value 'Allow'

Get-Item -path HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess